# Backend Coding Challenge

This repository demonstrates a backend architecture that handles asynchronous tasks, workflows, and job execution using TypeScript, Express.js, and TypeORM. The project showcases how to:

- Define and manage entities such as `Task` and `Workflow`.
- Use a `WorkflowFactory` to create workflows from YAML configurations.
- Implement a `TaskRunner` that executes jobs associated with tasks and manages task and workflow states.
- Run tasks asynchronously using a background worker.

## Key Features

1. **Entity Modeling with TypeORM**

   - **Task Entity:** Represents an individual unit of work with attributes like `taskType`, `status`, `progress`, and references to a `Workflow`.
   - **Workflow Entity:** Groups multiple tasks into a defined sequence or steps, allowing complex multi-step processes.

2. **Workflow Creation from YAML**

   - Use `WorkflowFactory` to load workflow definitions from a YAML file.
   - Dynamically create workflows and tasks without code changes by updating YAML files.

3. **Asynchronous Task Execution**

   - A background worker (`taskWorker`) continuously polls for `queued` tasks.
   - The `TaskRunner` runs the appropriate job based on a task’s `taskType`.

4. **Robust Status Management**

   - `TaskRunner` updates the status of tasks (from `queued` to `in_progress`, `completed`, or `failed`).
   - Workflow status is evaluated after each task completes, ensuring you know when the entire workflow is `completed` or `failed`.

5. **Dependency Injection and Decoupling**

   - `TaskRunner` takes in only the `Task` and determines the correct job internally.
   - `TaskRunner` handles task state transitions, leaving the background worker clean and focused on orchestration.

6. **Interdependent Task Support**

   - Tasks can define a `dependsOn` field referencing another step number.
   - The system waits for dependent tasks to complete before executing the current one.

7. **Final Workflow Results Aggregation**
   - The last task can summarize the output of all prior tasks.
   - The result is saved in both `task.output` and `workflow.finalResult`.

## Project Structure

```
src
├─ data/
│  └─ world_data.json        # Contains world data for analysis
│
├─ jobs/
│  ├─ Job.ts                 # Job interface
│  ├─ JobFactory.ts          # getJobForTaskType function for mapping taskType to a Job
│  ├─ DataAnalysisJob.ts     # Job implementation for mock data analysis
│  ├─ EmailNotificationJob.ts# Example job (unused)
│  ├─ PolygonAreaJob.ts      # Calculates area from GeoJSON using @turf/area
│  └─ ReportGenerationJob.ts # Aggregates previous task results into a report
│
├─ models/
│  ├─ Result.ts              # Defines the Result entity
│  ├─ Task.ts                # Defines the Task entity
│  └─ Workflow.ts            # Defines the Workflow entity
│
├─ routes/
│  ├─ analysisRoutes.ts      # POST /analysis endpoint to create workflows
│  ├─ workflowRoutes.ts      # GET /workflow/:id/status and /results
│  └─ defaultRoute.ts        # Basic ping response for availability check
│
├─ workflows/
│  ├─ WorkflowFactory.ts     # Creates workflows & tasks from a YAML definition
│  ├─ example_workflow.yml   # Sample workflow (analysis + notification)
│  ├─ polygon_area_test.yml  # Workflow for area calculation
│  └─ report_workflow_test.yml # Workflow with interdependent task & report
│
├─ workers/
│  ├─ taskRunner.ts          # Executes job, manages state, handles dependencies
│  └─ taskWorker.ts          # Background polling loop for queued tasks
│
├─ data-source.ts            # TypeORM DataSource configuration
└─ index.ts                  # Express.js server initialization & route setup
```

## Example YAML Configuration

```yaml
name: report_workflow_test
steps:
  - taskType: polygonArea
    stepNumber: 1
  - taskType: report
    stepNumber: 2
    dependsOn: 1
```

## Creating a Workflow via API

### Polygon Workflow

```bash
curl -X POST http://localhost:3000/analysis   -H "Content-Type: application/json"   -d '{
    "clientId": "test-client",
    "workflowName": "polygon_area_test",
    "geoJson": {
      "type": "Feature",
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[0,0],[0,1],[1,1],[1,0],[0,0]]]
      },
      "properties": {}
    }
  }'
```

### Report Workflow

```bash
curl -X POST http://localhost:3000/analysis   -H "Content-Type: application/json"   -d '{
    "clientId": "test-client",
    "workflowName": "report_workflow_test",
    "geoJson": {
      "type": "Feature",
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[0,0],[0,1],[1,1],[1,0],[0,0]]]
      },
      "properties": {}
    }
  }'
```

### Get Workflow Status

```bash
curl http://localhost:3000/workflow/<workflowId>/status
```

### Get Workflow Results

```bash
curl http://localhost:3000/workflow/<workflowId>/results
```
